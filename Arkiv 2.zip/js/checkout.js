document.addEventListener("DOMContentLoaded", () => {
    const cartItemsContainer = document.querySelector(".cart-items");
    const subtotalElement = document.getElementById("subtotal");
    const totalElement = document.getElementById("total");
    const discountInput = document.getElementById("apply-discount");

    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    // Save updated cart to localStorage
    function saveCart(updatedCart) {
        localStorage.setItem("cart", JSON.stringify(updatedCart));
    }

    // Render cart items
    function renderCartItems() {
        if (cart.length > 0) {
            cartItemsContainer.innerHTML = cart
                .map(item => `
                <div class="cart-item">
                    <img src="${item.mainImage}" alt="${item.name}" class="cart-item-image">
                    <span class="cart-item-name">${item.name}</span>
                    <input type="number" class="cart-item-quantity" value="${item.quantity}" min="1" data-id="${item.id}">
                    <button class="remove-item" data-id="${item.id}">Remove</button>
                    <span class="cart-item-price">GP ${(item.price * item.quantity).toFixed(2)}</span>
                </div>
            `).join("");
            attachCartListeners();
        } else {
            cartItemsContainer.innerHTML = "<p>Your cart is empty!</p>";
        }
    }

    // Calculate totals
    function calculateTotals() {
        const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
        subtotalElement.textContent = `GP ${subtotal.toFixed(2)}`;
        totalElement.textContent = `GP ${subtotal.toFixed(2)}`; // Adjust for discounts later
    }

    // Attach event listeners to quantity inputs and remove buttons
    function attachCartListeners() {
        // Handle quantity changes
        document.querySelectorAll(".cart-item-quantity").forEach(input => {
            input.addEventListener("change", (e) => {
                const productId = e.target.getAttribute("data-id");
                const newQuantity = parseInt(e.target.value, 10);
                if (!isNaN(newQuantity) && newQuantity > 0) {
                    updateItemQuantity(productId, newQuantity);
                } else {
                    e.target.value = 1; // Reset to 1 if invalid
                }
            });
        });

        // Handle item removal
        document.querySelectorAll(".remove-item").forEach(button => {
            button.addEventListener("click", (e) => {
                const productId = e.target.getAttribute("data-id");
                updateItemQuantity(productId, 0); // Set quantity to 0 to remove item
            });
        });
    }

    // Update item quantity or remove item
    function updateItemQuantity(productId, newQuantity) {
        const itemIndex = cart.findIndex(item => item.id === productId);
        if (itemIndex !== -1) {
            if (newQuantity > 0) {
                cart[itemIndex].quantity = newQuantity;
            } else {
                cart.splice(itemIndex, 1); // Remove item if quantity is 0
            }
            saveCart(cart); // Save updated cart
            renderCartItems(); // Re-render the cart
            calculateTotals(); // Update totals
        }
    }

    // Apply discount (placeholder)
    discountInput.addEventListener("click", () => {
        alert("Discounts coming soon!"); // Add real logic here
    });

    // Handle form submission
    const form = document.getElementById("checkout-form");
    form.addEventListener("submit", (e) => {
        e.preventDefault();
        alert("Order placed! Thank you for shopping.");
        localStorage.removeItem("cart"); // Clear the cart
        window.location.href = "/"; // Redirect to the home page
    });

    renderCartItems();
    calculateTotals();
});
